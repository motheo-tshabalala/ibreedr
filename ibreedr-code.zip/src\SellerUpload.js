import React, { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, Upload, X, Video, ChevronRight, ChevronLeft, Check, Building2, MapPin, Phone, User, Package, Percent } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from './supabaseClient';
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Label } from "./components/ui/label";
import { Textarea } from "./components/ui/textarea";

const ANIMAL_TYPES = [
  { value: 'cattle', label: 'Cattle' },
  { value: 'goats', label: 'Goats' },
  { value: 'sheep', label: 'Sheep' },
  { value: 'pigs', label: 'Pigs' },
  { value: 'chickens', label: 'Chickens' },
  { value: 'horses', label: 'Horses' },
  { value: 'donkeys', label: 'Donkeys' },
  { value: 'rabbits', label: 'Rabbits' }
];

const QUANTITY_OPTIONS = [1, 5, 10, 20, 50];

export default function SellerUpload() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [videoUploading, setVideoUploading] = useState(false);
  const [marketSuggestion, setMarketSuggestion] = useState(null);
  const [showPriceSuggestion, setShowPriceSuggestion] = useState(false);

  const [formData, setFormData] = useState({
    farm_name: '',
    seller_name: '',
    seller_phone: '',
    location: '',
    quantity: 1,
    is_bundle: false,
    bundle_discount: 0,
    animal_type: '',
    breed_type: '',
    pure_cross: '',
    age_years: '',
    age_months: '',
    teeth_age: '',
    weight_min: '',
    weight_max: '',
    pregnancy_status: '',
    sire_used: '',
    price: '',
    health_info: '',
    notes: '',
    images: [],
    video_url: '',
    facebook_url: '',
    instagram_url: '',
    whatsapp_number: '',
    website_url: '',
    gps_latitude: '',
    gps_longitude: ''
  });

  const totalSteps = 7;

  // Load user and profile
  useEffect(() => {
    const loadUserAndProfile = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        window.location.href = '/login';
        return;
      }
      setUser(user);

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (profile) {
        setProfile(profile);
        setFormData(prev => ({
          ...prev,
          farm_name: profile.farm_name || profile.full_name || '',
          seller_name: profile.full_name || '',
          seller_phone: profile.phone || '',
          location: profile.farm_location || ''
        }));
      }
    };

    loadUserAndProfile();
  }, []);

  // Fetch price suggestion
  const fetchPriceSuggestion = useCallback(async () => {
    const animalType = formData.animal_type;
    if (!animalType) return;

    try {
      // Simple price suggestion based on animal type
      const suggestions = {
        cattle: { min: 15000, max: 25000, avg: 20000, demand: 'high', trend: 'up' },
        goats: { min: 3000, max: 6000, avg: 4500, demand: 'medium', trend: 'stable' },
        sheep: { min: 2500, max: 5000, avg: 3800, demand: 'medium', trend: 'up' },
        pigs: { min: 4000, max: 7000, avg: 5500, demand: 'medium', trend: 'stable' },
        chickens: { min: 50, max: 80, avg: 65, demand: 'high', trend: 'up' },
        horses: { min: 20000, max: 50000, avg: 35000, demand: 'low', trend: 'stable' }
      };

      const suggestion = suggestions[animalType];
      if (suggestion) {
        setMarketSuggestion({
          range: { min: suggestion.min, max: suggestion.max },
          avg: suggestion.avg,
          demand: suggestion.demand,
          trend: suggestion.trend,
          sample_size: 10,
          confidence: 0.7,
          suggested_sweet_spot: {
            min: suggestion.avg * 0.9,
            max: suggestion.avg * 1.1
          }
        });
        setShowPriceSuggestion(true);
      }
    } catch (error) {
      console.error('Error fetching price suggestion:', error);
    }
  }, [formData.animal_type]);

  useEffect(() => {
    if (formData.animal_type) {
      const timer = setTimeout(() => {
        fetchPriceSuggestion();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [formData.animal_type, fetchPriceSuggestion]);

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files);
    setUploading(true);

    try {
      const imageUrls = [];
      for (const file of files) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `listings/${user?.id}/${fileName}`;

        const { error } = await supabase.storage
          .from('livestock-images')
          .upload(filePath, file);

        if (error) throw error;

        const { data: { publicUrl } } = supabase.storage
          .from('livestock-images')
          .getPublicUrl(filePath);

        imageUrls.push(publicUrl);
      }

      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...imageUrls]
      }));
    } catch (error) {
      console.error('Upload failed:', error);
      alert('Failed to upload images: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  const handleVideoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('video/')) {
      alert('Please upload a video file');
      return;
    }

    setVideoUploading(true);

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `videos/${user?.id}/${Date.now()}.${fileExt}`;

      const { error } = await supabase.storage
        .from('livestock-videos')
        .upload(fileName, file);

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('livestock-videos')
        .getPublicUrl(fileName);

      setFormData(prev => ({ ...prev, video_url: publicUrl }));
      alert('Video uploaded successfully!');
    } catch (error) {
      console.error('Video upload failed:', error);
      alert('Failed to upload video: ' + error.message);
    } finally {
      setVideoUploading(false);
    }
  };

  const removeImage = (index) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };

  const handleSubmit = async () => {
    setSubmitting(true);

    try {
      const pricePerHead = parseFloat(formData.price) || 0;
      const quantity = parseInt(formData.quantity) || 1;
      const discount = parseFloat(formData.bundle_discount) || 0;

      let totalPrice = pricePerHead * quantity;
      if (formData.is_bundle && discount > 0) {
        totalPrice = totalPrice * (1 - discount / 100);
      }

      const submitData = {
        user_id: user.id,
        farm_name: formData.farm_name,
        seller_name: formData.seller_name,
        seller_phone: formData.seller_phone,
        location: formData.location,
        quantity: quantity,
        is_bundle: formData.is_bundle,
        bundle_discount: formData.is_bundle ? discount : 0,
        price: pricePerHead,
        total_price: totalPrice,
        animal_type: formData.animal_type,
        breed_type: formData.breed_type,
        pure_cross: formData.pure_cross,
        age_years: parseInt(formData.age_years) || 0,
        age_months: parseInt(formData.age_months) || 0,
        teeth_age: formData.teeth_age,
        weight_min: formData.weight_min ? parseFloat(formData.weight_min) : null,
        weight_max: formData.weight_max ? parseFloat(formData.weight_max) : null,
        pregnancy_status: formData.pregnancy_status,
        sire_used: formData.sire_used,
        health_info: formData.health_info,
        notes: formData.notes,
        images: formData.images,
        video_url: formData.video_url,
        facebook_url: formData.facebook_url,
        instagram_url: formData.instagram_url,
        whatsapp_number: formData.whatsapp_number,
        website_url: formData.website_url,
        gps_latitude: formData.gps_latitude ? parseFloat(formData.gps_latitude) : null,
        gps_longitude: formData.gps_longitude ? parseFloat(formData.gps_longitude) : null,
        status: 'active'
      };

      const { error } = await supabase
        .from('livestock')
        .insert([submitData]);

      if (error) throw error;
      alert('Listing published successfully!');
      window.location.href = '/MyListings';

    } catch (err) {
      console.error('Submit error:', err);
      alert('Error: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1: return formData.farm_name && formData.location;
      case 2: return formData.quantity > 0;
      case 3: return formData.animal_type && formData.breed_type;
      case 4: return true;
      case 5: return true;
      case 6: return formData.price;
      case 7: return formData.images.length > 0;
      default: return true;
    }
  };

  const StepIndicator = () => (
    <div className="flex items-center justify-between mb-6">
      {[1, 2, 3, 4, 5, 6, 7].map((step) => (
        <div key={step} className="flex items-center">
          <button
            onClick={() => setCurrentStep(step)}
            className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all ${currentStep === step
                ? 'bg-primary-green text-white'
                : step < currentStep
                  ? 'bg-green-500 text-white'
                  : 'bg-gray-200 text-gray-500'
              }`}
          >
            {step < currentStep ? <Check className="w-4 h-4" /> : step}
          </button>
          {step < 7 && (
            <div className={`w-full h-0.5 mx-2 ${step < currentStep ? 'bg-green-500' : 'bg-gray-200'}`} />
          )}
        </div>
      ))}
    </div>
  );

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-center">Your Farm Information</h2>
            <p className="text-sm text-gray-500 text-center">This information appears on all your listings</p>

            <div className="p-4 bg-primary-green/5 rounded-lg border border-primary-green/20">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Building2 className="w-4 h-4 text-primary-green" />
                <span>Farm/Business Name *</span>
              </div>
              <Input
                value={formData.farm_name}
                onChange={(e) => setFormData({ ...formData, farm_name: e.target.value })}
                placeholder="e.g., Green Valley Farm"
                className="mt-1"
              />
            </div>

            <div className="p-4 bg-primary-green/5 rounded-lg border border-primary-green/20">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="w-4 h-4 text-primary-green" />
                <span>Farm Location *</span>
              </div>
              <Input
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="City, Province (e.g., Mpumalanga)"
                className="mt-1"
              />
            </div>

            <div className="p-4 bg-primary-green/5 rounded-lg border border-primary-green/20">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <User className="w-4 h-4 text-primary-green" />
                <span>Contact Name</span>
              </div>
              <Input
                value={formData.seller_name}
                onChange={(e) => setFormData({ ...formData, seller_name: e.target.value })}
                placeholder="Your name"
                className="mt-1"
              />
            </div>

            <div className="p-4 bg-primary-green/5 rounded-lg border border-primary-green/20">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Phone className="w-4 h-4 text-primary-green" />
                <span>Phone Number</span>
              </div>
              <Input
                type="tel"
                value={formData.seller_phone}
                onChange={(e) => setFormData({ ...formData, seller_phone: e.target.value })}
                placeholder="+27 XX XXX XXXX"
                className="mt-1"
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-center">How Many Animals?</h2>

            <div className="grid grid-cols-3 gap-3">
              {QUANTITY_OPTIONS.map((qty) => (
                <button
                  key={qty}
                  type="button"
                  onClick={() => setFormData({ ...formData, quantity: qty })}
                  className={`p-4 rounded-xl border-2 transition-all ${formData.quantity === qty
                      ? 'border-primary-green bg-primary-green/5'
                      : 'border-gray-200 hover:border-primary-green/50'
                    }`}
                >
                  <div className="text-2xl font-bold text-center">{qty}</div>
                  <div className="text-xs text-gray-500 text-center">Animals</div>
                </button>
              ))}
            </div>

            <div>
              <Label>Custom Quantity</Label>
              <Input
                type="number"
                min="1"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 1 })}
                className="mt-1"
              />
            </div>

            <div className="p-4 bg-amber-50 rounded-xl border border-amber-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Package className="w-5 h-5 text-amber-600" />
                  <div>
                    <p className="font-medium text-gray-900">Bundle Discount</p>
                    <p className="text-xs text-gray-500">Offer a discount for buying in bulk</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, is_bundle: !prev.is_bundle }))}
                  className={`w-12 h-6 rounded-full transition-colors relative ${formData.is_bundle ? 'bg-primary-green' : 'bg-gray-300'
                    }`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${formData.is_bundle ? 'translate-x-7' : 'translate-x-1'
                    }`} />
                </button>
              </div>

              {formData.is_bundle && (
                <div className="mt-3 pt-3 border-t border-amber-200">
                  <Label className="flex items-center gap-2">
                    <Percent className="w-4 h-4 text-amber-600" />
                    Discount Percentage (%)
                  </Label>
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.bundle_discount}
                    onChange={(e) => setFormData({ ...formData, bundle_discount: parseFloat(e.target.value) || 0 })}
                    placeholder="e.g., 10 for 10% off"
                    className="mt-1"
                  />
                </div>
              )}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-center">Animal Details</h2>

            <div>
              <Label>Animal Type *</Label>
              <select
                value={formData.animal_type}
                onChange={(e) => setFormData({ ...formData, animal_type: e.target.value })}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm mt-1"
              >
                <option value="">Select</option>
                {ANIMAL_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>

            <div>
              <Label>Breed Type *</Label>
              <Input
                value={formData.breed_type}
                onChange={(e) => setFormData({ ...formData, breed_type: e.target.value })}
                placeholder="e.g., Angus, Bonsmara"
                className="mt-1"
              />
            </div>

            <div>
              <Label>Pure / Cross</Label>
              <select
                value={formData.pure_cross}
                onChange={(e) => setFormData({ ...formData, pure_cross: e.target.value })}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm mt-1"
              >
                <option value="">Select</option>
                <option value="pure">Pure Breed</option>
                <option value="cross">Cross Breed</option>
              </select>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-center">Age & Weight</h2>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Age (Years)</Label>
                <Input type="number" value={formData.age_years} onChange={(e) => setFormData({ ...formData, age_years: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>Age (Months)</Label>
                <Input type="number" value={formData.age_months} onChange={(e) => setFormData({ ...formData, age_months: e.target.value })} className="mt-1" />
              </div>
            </div>

            <div>
              <Label>Teeth / Age Description</Label>
              <Input value={formData.teeth_age} onChange={(e) => setFormData({ ...formData, teeth_age: e.target.value })} placeholder="e.g., 8 teeth" className="mt-1" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Weight Min (KG)</Label>
                <Input type="number" value={formData.weight_min} onChange={(e) => setFormData({ ...formData, weight_min: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>Weight Max (KG)</Label>
                <Input type="number" value={formData.weight_max} onChange={(e) => setFormData({ ...formData, weight_max: e.target.value })} className="mt-1" />
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-center">Breeding Information</h2>

            <div>
              <Label>Pregnancy Status</Label>
              <select
                value={formData.pregnancy_status}
                onChange={(e) => setFormData({ ...formData, pregnancy_status: e.target.value })}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm mt-1"
              >
                <option value="">Select</option>
                <option value="pregnant">Pregnant</option>
                <option value="open">Open (Not Pregnant)</option>
                <option value="n/a">N/A</option>
              </select>
            </div>

            <div>
              <Label>Sire Used</Label>
              <Input value={formData.sire_used} onChange={(e) => setFormData({ ...formData, sire_used: e.target.value })} placeholder="e.g., Meatmaster Bull" className="mt-1" />
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-center">Price</h2>

            <div>
              <Label>Price per Animal (R) *</Label>
              <Input
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                placeholder="e.g., 18000"
                className="mt-1 text-lg font-semibold"
              />
            </div>

            {formData.quantity > 0 && formData.price && (
              <div className="bg-primary-green/5 rounded-xl p-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Price per head</span>
                  <span className="font-semibold">R {Number(formData.price).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm mt-1">
                  <span className="text-gray-600">Quantity</span>
                  <span className="font-semibold">{formData.quantity} animals</span>
                </div>
                <div className="flex justify-between text-sm mt-1">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-semibold">R {(Number(formData.price) * formData.quantity).toLocaleString()}</span>
                </div>
                {formData.is_bundle && formData.bundle_discount > 0 && (
                  <>
                    <div className="flex justify-between text-sm mt-1 text-amber-600">
                      <span>Bundle discount ({formData.bundle_discount}%)</span>
                      <span>- R {Math.round((Number(formData.price) * formData.quantity * formData.bundle_discount) / 100).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold mt-2 pt-2 border-t border-primary-green/20">
                      <span>Total Price</span>
                      <span className="text-primary-green">R {Math.round(Number(formData.price) * formData.quantity * (1 - formData.bundle_discount / 100)).toLocaleString()}</span>
                    </div>
                  </>
                )}
                {!formData.is_bundle && formData.quantity > 1 && (
                  <div className="flex justify-between text-lg font-bold mt-2 pt-2 border-t border-primary-green/20">
                    <span>Total Price</span>
                    <span className="text-primary-green">R {(Number(formData.price) * formData.quantity).toLocaleString()}</span>
                  </div>
                )}
              </div>
            )}

            {showPriceSuggestion && marketSuggestion && (
              <div className="bg-primary-green/5 border border-primary-green/20 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-primary-green">Market Intelligence</h4>
                  <span className="text-xs text-gray-500">
                    Based on {marketSuggestion.sample_size || 0} similar listings
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <p className="text-xs text-gray-500">Market Range</p>
                    <p className="text-sm font-semibold">
                      R{marketSuggestion.range?.min?.toLocaleString()} – R{marketSuggestion.range?.max?.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Average</p>
                    <p className="text-sm font-semibold">
                      R{marketSuggestion.avg?.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Demand</p>
                    <p className={`text-sm font-semibold ${marketSuggestion.demand === 'high' ? 'text-green-600' :
                        marketSuggestion.demand === 'medium' ? 'text-amber-600' :
                          'text-gray-600'
                      }`}>
                      {marketSuggestion.demand === 'high' && 'High'}
                      {marketSuggestion.demand === 'medium' && 'Medium'}
                      {marketSuggestion.demand === 'low' && 'Low'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <span>Trend: {marketSuggestion.trend === 'up' ? 'Rising' : marketSuggestion.trend === 'down' ? 'Falling' : 'Stable'}</span>
                  <span className="ml-auto text-xs text-gray-400">
                    Confidence: {Math.round((marketSuggestion.confidence || 0) * 100)}%
                  </span>
                </div>

                <div className="pt-3 border-t border-primary-green/10">
                  <p className="text-xs text-gray-600">
                    Suggested sweet spot: <span className="font-semibold text-primary-green">
                      R{marketSuggestion.suggested_sweet_spot?.min?.toLocaleString()} – R{marketSuggestion.suggested_sweet_spot?.max?.toLocaleString()}
                    </span>
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      const avg = marketSuggestion.avg || 0;
                      setFormData({ ...formData, price: Math.round(avg).toString() });
                    }}
                    className="mt-2 text-xs text-primary-green hover:underline"
                  >
                    Use average price
                  </button>
                </div>
              </div>
            )}
          </div>
        );

      case 7:
        return (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-center">Health, Notes & Photos</h2>

            <div>
              <Label>Health Information</Label>
              <Textarea value={formData.health_info} onChange={(e) => setFormData({ ...formData, health_info: e.target.value })} placeholder="Vaccinations, health status, vet checks..." rows={3} className="mt-1" />
            </div>

            <div>
              <Label>Additional Notes</Label>
              <Textarea value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} placeholder="Any other information..." rows={3} className="mt-1" />
            </div>

            <div>
              <Label>Social Media (Optional)</Label>
              <Input value={formData.facebook_url} onChange={(e) => setFormData({ ...formData, facebook_url: e.target.value })} placeholder="Facebook URL" className="mt-1" />
              <Input value={formData.instagram_url} onChange={(e) => setFormData({ ...formData, instagram_url: e.target.value })} placeholder="Instagram URL" className="mt-2" />
              <Input value={formData.whatsapp_number} onChange={(e) => setFormData({ ...formData, whatsapp_number: e.target.value })} placeholder="WhatsApp Number" className="mt-2" />
            </div>

            <div className="border-2 border-dashed border-gray-200 rounded-lg p-4 text-center">
              <div className="grid grid-cols-3 gap-2 mb-3">
                {formData.images.map((url, index) => (
                  <div key={index} className="relative aspect-square rounded-lg overflow-hidden bg-gray-100">
                    <img src={url} alt="Upload" className="w-full h-full object-cover" />
                    <button type="button" onClick={() => removeImage(index)} className="absolute top-1 right-1 p-1 bg-white/80 rounded-full">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                <label className="aspect-square rounded-lg border-2 border-dashed border-gray-200 flex flex-col items-center justify-center cursor-pointer hover:border-primary-green transition">
                  <Upload className="w-6 h-6 text-gray-400 mb-1" />
                  <span className="text-xs text-gray-400">Add Photo</span>
                  <input type="file" multiple accept="image/*" onChange={handleImageUpload} className="hidden" disabled={uploading} />
                </label>
              </div>
              {uploading && <p className="text-sm text-primary-green mt-2">Uploading images...</p>}
            </div>

            <div className="border-2 border-dashed border-gray-200 rounded-lg p-4 text-center">
              <Video className="w-6 h-6 text-gray-400 mx-auto mb-1" />
              <p className="text-sm text-gray-400 mb-2">Upload a video (Optional)</p>
              <input type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" id="videoUpload" />
              <Button type="button" variant="outline" size="sm" onClick={() => document.getElementById('videoUpload').click()} disabled={videoUploading}>
                {videoUploading ? 'Uploading...' : 'Choose Video'}
              </Button>
              {formData.video_url && <p className="text-green-600 text-sm mt-2">Video uploaded</p>}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-warm-white pb-20">
      <div className="bg-white border-b sticky top-0 z-30">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
          <Link to="/livestock">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-bold">List Livestock</h1>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6">
        <Card>
          <CardContent className="p-6">
            <StepIndicator />

            {renderStep()}

            <div className="flex justify-between gap-4 mt-8">
              {currentStep > 1 && (
                <Button variant="outline" onClick={prevStep} className="gap-2">
                  <ChevronLeft className="w-4 h-4" />
                  Back
                </Button>
              )}

              {currentStep < totalSteps ? (
                <Button onClick={nextStep} disabled={!isStepValid()} className="gap-2 ml-auto bg-primary-green hover:bg-primary-green-dark">
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              ) : (
                <Button onClick={handleSubmit} disabled={submitting || !isStepValid()} className="gap-2 ml-auto bg-primary-green hover:bg-primary-green-dark">
                  {submitting ? 'Publishing...' : 'Publish Listing'}
                  <Check className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}